#ifndef HEADER_FreeBSDCRT
#define HEADER_FreeBSDCRT
/*
htop - UnsupportedCRT.h
(C) 2014 Hisham H. Muhammad
Released under the GNU GPL, see the COPYING file
in the source distribution for its full text.
*/

void CRT_handleSIGSEGV(int sgn);

#endif
