#ifndef HEADER_OpenBSDCRT
#define HEADER_OpenBSDCRT
/*
htop - UnsupportedCRT.h
(C) 2014 Hisham H. Muhammad
(C) 2015 Michael McConville
Released under the GNU GPL, see the COPYING file
in the source distribution for its full text.
*/

void CRT_handleSIGSEGV(int sgn);

#endif
